﻿namespace SharedTrip.Models
{
    public class Trip
    {
    }
}
